# Incognito

This is the official and latest source code of **Incognito**. Brought to you by the developers behind the software. This repository was created to provide a central, safe, and malware-free location for accessing and reviewing the code.

## Disclaimer
Please note that the version of the software provided here was unfinished at the time of the leak. As such, it may be buggy and prone to crashes.

> [!WARNING]  
> We have not had the opportunity to finalize development, and users should proceed with caution.

> [!CAUTION]
> **We are not liable for any damages caused or any consequences such as bans that may result from using this software. Users should proceed at their own risk.**

## Background
Originally, this project was a maintained private and unfinished build of *Incognito*. It was subsequently leaked privately to a few, who utilized it without our consent to profit from our work.

However, following a public leak, we have decided to officially release the latest unleaked version of the code to prevent the spread of potentially modified, unsafe versions.

## Learning and Usage
This repository is a resource for learning and understanding. We hope that by making this code available, we can support the community in using and improving their own software safely and effectively.

## License
Please ensure you **[read and follow the license](/LICENSE)** associated with this project. The license outlines the permissible uses and restrictions for this code. Adhering to these terms is crucial for legal use and further development of the software.

Thank you, - **Incognito Development Team**
- [@piomanly](https://github.com/piomanly)
- [@phoriah](https://github.com/phoriah)
- [@usragent](https://github.com/usragent)
- [@Ficelloo](https://github.com/Ficelloo)
- [@jLn0n](https://github.com/jLn0n)
